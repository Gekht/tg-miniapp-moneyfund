// Apps Script: HTTP API для записи в Google Sheets (если хочешь писать напрямую из Mini App)
const SHEET = SpreadsheetApp.openById('PASTE_SPREADSHEET_ID');
const SHEET_PAYMENTS = 'Payments';

function doPost(e) {
  const body = JSON.parse(e.postData.contents || '{}');
  if (body.t === 'payment') {
    const sh = SHEET.getSheetByName(SHEET_PAYMENTS);
    if (!sh) throw new Error('Payments sheet not found');
    const cid = String(body.cid || '');
    const uid = String(body.user_id || ''); // можно прислать с бэкенда
    const amount = body.amount || '';
    const note = body.note || '';
    sh.appendRow([cid, uid, new Date().toISOString(), amount, note]);
    return ContentService.createTextOutput(JSON.stringify({ok:true}));
  }
  return ContentService.createTextOutput(JSON.stringify({ok:false, err:'unknown type'}));
}
