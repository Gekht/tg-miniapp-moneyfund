# Python-бот: кнопка, открывающая Mini App и приём web_app_data
# pip install python-telegram-bot==21.4
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import json, os

BOT_TOKEN = os.getenv("BOT_TOKEN")
MINIAPP_URL = os.getenv("MINIAPP_URL", "https://your-domain.github.io/tg-miniapp-moneyfund/")  # GitHub Pages/Netlify

async def app_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Можно передать id сбора ?cid=1
    url = f"{MINIAPP_URL}?cid=1"
    kb = [[KeyboardButton(text="Открыть Mini App", web_app=WebAppInfo(url=url))]]
    await update.message.reply_text("Открой мини‑ап:", reply_markup=ReplyKeyboardMarkup(kb, resize_keyboard=True))

async def webapp_data(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Пользователь нажал кнопку "Отправить" в Mini App → приходит web_app_data
    if update.message and update.message.web_app_data:
        data = update.message.web_app_data.data
        try:
            payload = json.loads(data)
        except Exception:
            payload = {"raw": data}

        # здесь можно записать в Google Sheets (через gspread) или прокинуть в GAS API
        await update.message.reply_text(f"Получил данные из Mini App: {payload}")
    else:
        await update.message.reply_text("Жду данные из Mini App...")

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("app", app_cmd))
    app.add_handler(MessageHandler(filters.StatusUpdate.WEB_APP_DATA, webapp_data))
    app.run_polling()

if __name__ == "__main__":
    main()
